package com.belajarubic.restaurant_jetpackcompose.ui.common

class Utils {
    companion object {
        const val delaySplashScreen: Long = 3000L
        const val argumentDetailScreen: String = "restaurantId"
    }
}